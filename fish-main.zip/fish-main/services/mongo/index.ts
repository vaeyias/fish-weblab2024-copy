/**
 * Please note that DEV and PROD modes create different collections.
 * They should still work all the same though!
 */

export * from "./mongoose";
