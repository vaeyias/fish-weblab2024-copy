export enum AnimalSprite {
    COW = "cow",
    BEAR = "bear",
    BEAVER = "beaver",
    BUNNY = "bunny",
    CAT = "cat",
    DUCK = "duck",
    HEDGEHOG = "hedgehog",
    PANDA = "panda",
    PENGUIN = "penguin",
    PIG = "pig",
    SHEEP = "sheep",
    SHIBA = "shiba",
  }