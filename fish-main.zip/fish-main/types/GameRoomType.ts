export enum GameRoomType {
    SENTENCE_SYMPHONY = "sentence-symphony",
  }