export enum PlayerRoomStatus {
    EXTERIOR = "exterior",
    INTERIOR = "interior",
    STUDY = "studyroom",
    SENTENCE_SYMPHONY = "sentence-symphony",
  }

export const GAME_ROOM_PLAYER_STATUSES = [ PlayerRoomStatus.SENTENCE_SYMPHONY ];