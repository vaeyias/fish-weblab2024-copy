import React from 'react'

export default function NoDuplicateTabsPage() {
  return (
    <div>bruh why</div>
  )
}
