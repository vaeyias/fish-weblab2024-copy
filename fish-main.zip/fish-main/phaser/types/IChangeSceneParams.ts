export interface IChangeSceneParams {
  channelName: string;
  oldScene: string;
  newScene: string;
  targetId?: string;
}
