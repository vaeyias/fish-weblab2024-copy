export interface IRedirectParams {
    channelName: string;
    redirectLink: string;
    targetId: string | null;
}